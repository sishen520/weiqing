


<!DOCTYPE html>
    <meta name="baidu-site-verification" content="XDk93xXVav" />
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="Keywords" content="魏晴，小2小2小小巫" /><meta name="Description" content="魏晴" /><link href="css/index.css" rel="stylesheet" /><link href="./css/base.css" rel="stylesheet" /><link href="./css/style.css" rel="stylesheet" />
    <title>你一直在向前走，从未回头</title>
    <link href="./css/new.css" rel="stylesheet" />
    <link rel="shortcut icon" href="images/tubiao.ico">
<title>

</title></head>
<body>
    <header>
        <h1><a href="/">魏晴</a></h1>
        <p>趁我们都还年轻,多欣赏下沿途的风景，不要错过了流年里温暖的人和物....</p>
    </header>
    <!--nav begin-->
    <div id="nav">
        <ul>
            <li><a href="/">首页</a></li>
            <li><a href="jilu.php">生活记录</a></li>
            <li><a href="photo.php">相册</a></li>
            <li><a href="about.php">关于我</a></li>
            <li><a href="messageBoard.php">留言板</a></li>
            <li><a href="yinyue.php" target="_blank">音乐欣赏</a></li>
        </ul>
    </div>
    <!--nav end-->
    <article class="blogs">
        <div id="l_box">
          
             <div style="line-height:33px">
                 <p class="p1">现在的位置：<a href="/">首页</a> &gt;<a href="jilu.php">生活记录</a> &gt;文章</p>
                    </div>    

    <article class="blogs">
        <div class="index_about">
            <h2 class="c_titile">你一直在向前走，从未回头</h2>
            <p class="box_c"><span class="d_time">发布时间：2016-04-29 21:55:52</span><span>编辑：刘坤</span><span>QQ：<a target='_blank' href='http://wpa.qq.com/msgrd?v=3&uin=1218639019&site=qq&menu=yes'>1218639019</a></span></p>

            <ul class="infos">

                              <audio src="http://jx.xcsee.cn/music/Magnum Opus - Nocturne.mp3 "  controls autoplay='autoplay'></audio><br>
                               <!--音乐名：Magnum Opus - Nocturne.mp3   -->
<p>
	<span style="white-space:nowrap;"><br>

</span>
</p>
                <p>猫喜欢吃鱼，可猫不会游泳。<br>
&nbsp;&nbsp;&nbsp;&nbsp;鱼喜欢吃蚯蚓，可鱼又不能上岸。<br>
&nbsp;&nbsp;&nbsp;&nbsp;上帝给了你很多诱惑，却不让你轻易得到。<br>
&nbsp;&nbsp;&nbsp;&nbsp;但是，总不能流血就喊痛，怕黑就开灯，想念就联系。<br>
&nbsp;&nbsp;&nbsp;&nbsp;今天再大的事，到了明天就是小事；<br>
&nbsp;&nbsp;&nbsp;&nbsp;今年再大的事，到了明年就是故事。<br>
&nbsp;&nbsp;&nbsp;&nbsp;我们最多也就是个有故事的人，<br>
&nbsp;&nbsp;&nbsp;&nbsp;所以，人生就像蒲公英，看似自由，却身不由己。<br>
&nbsp;&nbsp;&nbsp;&nbsp;有些事，不是不在意，而是在意了又能怎样，<br>
&nbsp;&nbsp;&nbsp;&nbsp;人生没有如果，只有结果<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;每个人的生命中也许都会有那么一段刻骨铭心，<br>
&nbsp;&nbsp;&nbsp;&nbsp;我们用尽全力爱过，<br>
&nbsp;&nbsp;&nbsp;&nbsp;但是，<br>
&nbsp;&nbsp;&nbsp;&nbsp;千万要记住，<br>
&nbsp;&nbsp;&nbsp;&nbsp;无论你是不是感觉再也不会去那样爱一个人，<br>
&nbsp;&nbsp;&nbsp;&nbsp;都要相信爱情，<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;我知道你是一个有故事的人，<br>
&nbsp;&nbsp;&nbsp;&nbsp;你一直在努力的向前走，<br>
&nbsp;&nbsp;&nbsp;&nbsp;从未回过头。<br></p>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/weimei.jpg' />
                <div><br /></div>
            </ul>
            <div class="keybq">
                <p><span>我是刘坤，我为自己代言！</span></p>

            </div>
            <div class="ad"></div>
            <div class="nextinfo">
                <p>上一篇：<a href='jilu-04.php'>这是一种什么样的体验</a></p>
                <p>下一篇：<a href='jilu-06.php'>我亦曾爱过你</a></p><br>
            </div>

          <TABLE borderColor=green  height=0 width=1028 cellPadding=0 width=100 align=center border=1>
<TBODY>
<TR>
<TD>
    
</TD></TR></TBODY></TABLE><br>
            

<!-- 评论代码 -->
            
        </div>
        
        
        
                <aside class="right">

            <div class="blank"></div>


        </aside>
    </article>

        </div>
        <div id="r_box">
            <aside class="right">
                <div class="rnav">
                    <ul>
                        <li class="rnav1"><a href="http://vip.xcsee.cn" target="_blank">死神影院</a></li>
                        <li class="rnav2"><a href="http://www.weiqing.cf/weiqing.html" target="_blank">魏晴专属</a></li>
                        <li class="rnav3"><a href="jilu.php" target="_blank">生活记录</a></li>
                        <li class="rnav4"><a href="yinyue.php" target="_blank">音乐欣赏</a></li>
                    </ul>
                </div>
    </article>
<footer>
  <p>Design by 刘坤</p>
</footer>
</body>
</html>