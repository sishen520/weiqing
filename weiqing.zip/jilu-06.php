


<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <meta name="baidu-site-verification" content="XDk93xXVav" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="Keywords" content="魏晴，小2小2小小巫" /><meta name="Description" content="魏晴" /><link href="css/index.css" rel="stylesheet" /><link href="./css/base.css" rel="stylesheet" /><link href="./css/style.css" rel="stylesheet" />
    <title>我亦曾爱过你</title>
    <link href="./css/new.css" rel="stylesheet" />
    <link rel="shortcut icon" href="images/tubiao.ico">
<title>

</title></head>
<body>
    <header>
        <h1><a href="/">魏晴</a></h1>
        <p>趁我们都还年轻,多欣赏下沿途的风景，不要错过了流年里温暖的人和物....</p>
    </header>
    <!--nav begin-->
    <div id="nav">
        <ul>
            <li><a href="/">首页</a></li>
            <li><a href="jilu.php">生活记录</a></li>
            <li><a href="photo.php">相册</a></li>
            <li><a href="about.php">关于我</a></li>
            <li><a href="messageBoard.php">留言板</a></li>
            <li><a href="yinyue.php" target="_blank">音乐欣赏</a></li>
        </ul>
    </div>
    <!--nav end-->
    <article class="blogs">
        <div id="l_box">
          
             <div style="line-height:33px">
                 <p class="p1">现在的位置：<a href="/">首页</a> &gt;<a href="jilu.php">生活记录</a> &gt;文章</p>
                    </div>    

    <article class="blogs">
        <div class="index_about">
            <h2 class="c_titile">我亦曾爱过你</h2>
            <p class="box_c"><span class="d_time">发布时间：2016-05-15 15:34:52</span><span>编辑：刘坤</span><span>QQ：<a target='_blank' href='http://wpa.qq.com/msgrd?v=3&uin=1218639019&site=qq&menu=yes'>1218639019</a></span></p>

                  <ul class="infos">
                               <audio src="http://jx.xcsee.cn/music/Magnum Opus - Nocturne.mp3 "  controls autoplay='autoplay'></audio><br>
                               <!--音乐名：Magnum Opus - Nocturne.mp3   -->
<p>
	<span style="white-space:nowrap;"><br>

</span>
</p>
                <p>
                我爱过你，你知道的。<br>
&nbsp;&nbsp;&nbsp;&nbsp;但是你说过，<br>
&nbsp;&nbsp;&nbsp;&nbsp;最笨的人才会把友情变为爱情,最后变为陌生人，<br>
&nbsp;&nbsp;&nbsp;&nbsp;所以我也就真的退却了。</p>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/guanzhu9.png' width=480 height=360/><br>
                <p>
                我总是想的特别多，<br>
&nbsp;&nbsp;&nbsp;&nbsp;我当时真的是在想，<br>
&nbsp;&nbsp;&nbsp;&nbsp;我马上要毕业了，而你只是高一，<br>
&nbsp;&nbsp;&nbsp;&nbsp;而你到大学的时候我也将大学毕业了，<br>
&nbsp;&nbsp;&nbsp;&nbsp;即使我们在一起你也不会快乐。<br>
&nbsp;&nbsp;&nbsp;&nbsp;毕竟我们总在错过。
                </p>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/guanzhu13.png' width=480 height=360/><br>
                <p>
                我不知道我当时在想什么，<br>
&nbsp;&nbsp;&nbsp;&nbsp;以至于我连这个都没看懂。<br>
                    </p>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/guanzhu15.png' width=480 height=370 /><br>
                      <p>
                       还有你给我留的言，<br>
&nbsp;&nbsp;&nbsp;&nbsp;米修（Miss you）的意思多简单，<br>
&nbsp;&nbsp;&nbsp;&nbsp;但是我当时竟然不知道!<br>
&nbsp;&nbsp;&nbsp;&nbsp;还要到后来让别人来提醒我。<br>
                </p>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/guanzhu10.png' width=480 height=250 /><br>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/guanzhu11.png' width=480 height=250 /><br>
                      <p>
高考结束我毕业了，<br>
&nbsp;&nbsp;&nbsp;&nbsp;你给我留言<br>
&nbsp;&nbsp;&nbsp;&nbsp;你问我还回去吗<br>
&nbsp;&nbsp;&nbsp;&nbsp;我说你要是有男朋友了我就不回去了。<br>
&nbsp;&nbsp;&nbsp;&nbsp;后来我去过一次，那是我们最后一次见面。<br>
&nbsp;&nbsp;&nbsp;&nbsp;后来你有男朋友了，<br>
&nbsp;&nbsp;&nbsp;&nbsp;后来，你有男朋友了，<br>
&nbsp;&nbsp;&nbsp;&nbsp;所以我去找你也只是在你们学校转了两圈罢了。<br>
                      </p>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/guanzhu14.png'  width=480 height=420 /><br>
                      <p>
你不记得了吧<br>
&nbsp;&nbsp;&nbsp;&nbsp;我空间留言第1314条<br>
&nbsp;&nbsp;&nbsp;&nbsp;是你给我留的<br>
&nbsp;&nbsp;&nbsp;&nbsp;你说你不贪心，只要不要把你给忘了<br>
&nbsp;&nbsp;&nbsp;&nbsp;我怎么会忘掉你，<br>
&nbsp;&nbsp;&nbsp;&nbsp;我怎么可能忘掉你。<br>
                      </p>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/guanzhu12.png'  width=480 height=500 /><br>
                      <p>
人们都说，一个人越缺什么越炫耀什么。<br>
&nbsp;&nbsp;&nbsp;&nbsp;结果我发现我之前总是在空间里发一些女孩的照片说是我女神<br>
&nbsp;&nbsp;&nbsp;&nbsp;甚至有的都没见过面。<br>
&nbsp;&nbsp;&nbsp;&nbsp;但我叫你的时候总是叫爱妃，<br>
&nbsp;&nbsp;&nbsp;&nbsp;因为你在我心中与众不同。<br>
                      </p>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/guanzhu4.jpg'  width=480 height=360 /><br>
                      <p>
你评论我这条说说的时候，<br>
&nbsp;&nbsp;&nbsp;&nbsp;你说我几百年前的照片都能找到，<br>
&nbsp;&nbsp;&nbsp;&nbsp;其实我很早就保存了，并没有刻意的去找。<br>
&nbsp;&nbsp;&nbsp;&nbsp;我想留下关于你的一切。<br>            
                      </p>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/guanzhu5.jpg'  width=480 height=500 /><br>
                      <p>
                          我发说说的时候喜欢@你<br>
&nbsp;&nbsp;&nbsp;&nbsp;我总是想到的就是你<br>
&nbsp;&nbsp;&nbsp;&nbsp;即使你很少评论我的说说。<br>
                      </p>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/guanzhu2.jpg'  width=480 height=500 /><br>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/guanzhu1.jpg'  width=480 height=500 /><br>
                      <p>
                    <font face=仿宋 color=red size=6>      
                          但是，这都是过去了。
                          </font>
                      </p>
                      
                      
                      <p>
                          你不知道你自己后来对我多冷，<br>
&nbsp;&nbsp;&nbsp;&nbsp;我自己总是忍不住去看你空间，<br>
&nbsp;&nbsp;&nbsp;&nbsp;评论你的动态。<br>
&nbsp;&nbsp;&nbsp;&nbsp;但我感觉你似乎总是针对我，<br>
&nbsp;&nbsp;&nbsp;&nbsp;我没办法。我不知道应该怎么做。<br>
                      </p>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/guanzhu3.jpg'  width=480 height=400 /><br>
                      <p>
你有男朋友了，<br>
&nbsp;&nbsp;&nbsp;&nbsp;你说你不想他误会的时候你不知道我多难受，<br>
&nbsp;&nbsp;&nbsp;&nbsp;你有男朋友没有让我特别难过。<br>
&nbsp;&nbsp;&nbsp;&nbsp;最难过的是，<br>
&nbsp;&nbsp;&nbsp;&nbsp;你把我当做了第三者。<br>
                      </p>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/guanzhu16.png' /><br>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/guanzhu17.png' /><br>
                      <p>
                      我开通了黄钻，<br>
&nbsp;&nbsp;&nbsp;&nbsp;设置隐身访问，<br>
&nbsp;&nbsp;&nbsp;&nbsp;我没什么可以做的，<br>
&nbsp;&nbsp;&nbsp;&nbsp;我还可以看你的空间。<br>
&nbsp;&nbsp;&nbsp;&nbsp;真好。<br>
                      </p>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/yinshen.png' /><br>
                      <p>
                          关掉空间<br>
&nbsp;&nbsp;&nbsp;&nbsp;我把我放下很久的佛经又拿出来了。<br>
&nbsp;&nbsp;&nbsp;&nbsp;我把我许久没进的“佛门吧”拿起来了。<br>
&nbsp;&nbsp;&nbsp;&nbsp;我相信她会帮助我走过去，<br>
&nbsp;&nbsp;&nbsp;&nbsp;我相信。<br>
                      </p>
&nbsp;&nbsp;&nbsp;&nbsp;<img src='images/guanzhu18.png' /><br>
                <div><br /></div>
            </ul>
            <div class="keybq">
                <p><span>我是刘坤，我为自己代言！</span></p>

            </div>
            <div class="ad"></div>
            <div class="nextinfo">
                <p>上一篇：<a href='jilu-04.php'>你一直在向前走，从未回头</a></p>
                <p>下一篇：<a href='jilu-07.php'>亲爱的，别留我一个人在这里</a></p><br>
            </div>

          <TABLE borderColor=green  height=0 width=1028 cellPadding=0 width=100 align=center border=1>
<TBODY>
<TR>
<TD>
    
</TD></TR></TBODY></TABLE><br>
            

<!-- 评论代码 -->
            
        </div>
        
        
        
                <aside class="right">

            <div class="blank"></div>


        </aside>
    </article>

        </div>
        <div id="r_box">
            <aside class="right">
                <div class="rnav">
                    <ul>
                        <li class="rnav1"><a href="http://vip.xcsee.cn" target="_blank">死神影院</a></li>
                        <li class="rnav2"><a href="http://www.weiqing.cf/weiqing.html" target="_blank">魏晴专属</a></li>
                        <li class="rnav3"><a href="jilu.php" target="_blank">生活记录</a></li>
                        <li class="rnav4"><a href="yinyue.php" target="_blank">音乐欣赏</a></li>
                    </ul>
                </div>
    </article>
<footer>
  <p>Design by 刘坤</p>
</footer>
</body>
</html>