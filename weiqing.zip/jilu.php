


<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <meta name="baidu-site-verification" content="XDk93xXVav" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="Keywords" content="魏晴，小2小2小小巫" /><meta name="Description" content="魏晴" /><link href="css/index.css" rel="stylesheet" /><link href="./css/base.css" rel="stylesheet" /><link href="./css/style.css" rel="stylesheet" />
    <link href="css/page_1.css" rel="stylesheet" />
    <link rel="shortcut icon" href="images/tubiao.ico">
    <title>生活记录</title>
<title>

</title></head>
<body>
    <header>
        <h1><a href="/">liukun's Blog</a></h1>
        <p>趁我们都还年轻,多欣赏下沿途的风景，不要错过了流年里温暖的人和物....</p>
    </header>
    <!--nav begin-->
    <div id="nav">
        <ul>
    <li><a href="/">首页</a></li>
    <li><a href="jilu.php">生活记录</a></li>
    <li><a href="photo.php">相册</a></li>
    <li><a href="about.php">关于我</a></li>
    <li><a href="messageBoard.php">留言板</a></li>
    <li><a href="yinyue.php" target="_blank">音乐欣赏</a></li>
        </ul>
    </div>
    <!--nav end-->
    <article class="blogs">
        <div id="l_box">
            
             <div style="line-height:33px">
                 <p class="p1">现在的位置：<a href="/">首页</a> &gt;生活记录</p>
                    </div>
        <div class="newblog left" style="margin-top:-23px">
            <br><br>
            
                  <div class="line"></div>
            <h2><a title="亲爱的，别留我一个人在这里" href="jilu-07.php" target="_blank">亲爱的，别留我一个人在这里<font face=宋体 color=red>[置顶]</font></a></h2>
            <p class="dateview1"><span>发布时间：2016-06-02</span><span>编辑：刘坤</span></p>
            <figure><a title="亲爱的，别留我一个人在这里" href="jilu-07.php" target="_blank">
                <img src="images/tupian/20160602.png" alt="亲爱的，别留我一个人在这里"></a></figure>
            <ul class="nlist">
                <p>就在我认为我快要习惯快要淡忘掉你有男朋友带给我的忧伤之际。就在我在空间说我要努力为以后努力的时候。你像是故意的，你不会不知道我有多难过。....</p>
                <a href="jilu-07.php"  target="_blank" title="亲爱的，别留我一个人在这里"  class="readmore">阅读全文>></a>
            </ul>
            
            
                        <div class="line"></div>
            <h2><a title="我亦曾爱过你" href="jilu-06.php" target="_blank">我亦曾爱过你</a></h2>
            <p class="dateview1"><span>发布时间：2016-05-15</span><span>编辑：刘坤</span></p>
            <figure><a title="我亦曾爱过你" href="jilu-06.php" target="_blank">
                <img src="images/shanggan.jpg" alt="我亦曾爱过你"></a></figure>
            <ul class="nlist">
                <p>我爱过你，你知道的。但是你说过，最笨的人才会把友情变为爱情,最后变为陌生人，所以我也就真的退却了。....</p>
                <a href="jilu-06.php"  target="_blank" title="我亦曾爱过你"  class="readmore">阅读全文>></a>
            </ul>
            
            <div class="line"></div>
            <h2><a title="【死神】你无法体会我的孤独。" href="jilu-02.php" target="_blank">【死神】你无法体会我的孤独。</a></h2>
            <p class="dateview1"><span>发布时间：2016-04-27</span><span>编辑：刘坤</span></p>
            <figure><a title="【死神】你无法体会我的孤独。" href="jilu-02.php" target="_blank">
                <img src="images/night.jpg" alt="【死神】你无法体会我的孤独。"></a></figure>
            <ul class="nlist">
                <p>我曾经在游戏里跟人骂的狗血喷头，有人误解我我会冲上去跟他吵的天昏地暗来证明自己做的并没有错。如今，我却不想说一句话。因为我不知道如何去说。....</p>
                <a href="jilu-02.php"  target="_blank" title="【死神】你无法体会我的孤独。"  class="readmore">阅读全文>></a>
            </ul>
            
            <div class="line"></div>
            <h2><a title="如果这个城市只剩我和你" href="jilu-03.php" target="_blank">如果这个城市只剩我和你</a></h2>
            <p class="dateview1"><span>发布时间：2016-04-28</span><span>作者：墨小芭</span><span>编辑：刘坤</span></p>
            <figure><a title="如果这个城市只剩我和你" href="jilu-03.php" target="_blank">
                <img src="images/jilu03.jpg" alt="如果这个城市只剩我和你"></a></figure>
            <ul class="nlist">
                <p>我在网络上看到这样一句话，是说，所谓的成熟就是，曾经怎样努力都得不到的，现在不想要了。 ....</p>
                <a href="jilu-03.php" target="_blank" title="如果这个城市只剩我和你"  class="readmore">阅读全文>></a>
            </ul>
            
            <div class="line"></div>
            <h2><a title="这是一种什么样的体验" href="jilu-04.php" target="_blank">这是一种什么样的体验</a></h2>
            <p class="dateview1"><span>发布时间：2016-04-29</span><span>编辑：刘坤</span></p>
            <figure><a title="这是一种什么样的体验" href="jilu-04.php" target="_blank">
                <img src="images/jilu-04.png" alt="这是一种什么样的体验"></a></figure>
            <ul class="nlist">
                <p>每个人的生命中也许都会有那么一段刻骨铭心,我们用尽全力爱过但是，千万要记住，无论你是不是感觉再也不会去那样爱一个人，都要相信爱情！....</p>
                <a href="jilu-04.php" target="_blank" title="这是一种什么样的体验"  class="readmore">阅读全文>></a>
            </ul>

            <div class="line"></div>
            <h2><a title="你一直在向前走，从未回头" href="jilu-05.php" target="_blank">你一直在向前走，从未回头</a></h2>
            <p class="dateview1"><span>发布时间：2016-04-29</span><span>编辑：刘坤</span></p>
            <figure><a title="你一直在向前走，从未回头" href="jilu-05.php" target="_blank">
                <img src="images/04.jpg" alt="你一直在向前走，从未回头"></a></figure>
            <ul class="nlist">
                <p>有些事，不是不在意，而是在意了又能怎样，人生没有如果，只有结果。你一直在努力向前走，从未回过头。 ....</p>
                <a href="jilu-05.php" target="_blank" title="你一直在向前走，从未回头"  class="readmore">阅读全文>></a>
            </ul>
            
            
            <div class="line"></div>
            <div class="blank"></div>
            <!--------------------------分页开始------------------------------->
            <div class="page">        <b>1</b> <a class='pageLink' href='?pageIndex=2&pageSize=3&id=1'>2</a>   <a class='pageLink' href='?pageIndex=2&pageSize=3&id=1'>>></a>  <a class='pageLink' href='?pageIndex=13&pageSize=3&id=1'>末页</a>  第1页 / 共1页</div>
          
            <!--------------------------分页结束------------------------------->
        </div>

        </div>
        <div id="r_box">
            <aside class="right">
                <div class="rnav">
                    <ul>
                        <li class="rnav1"><a href="http://vip.xcsee.cn" target="_blank">死神影院</a></li>
                        <li class="rnav2"><a href="http://www.weiqing.cf/weiqing.html" target="_blank">魏晴专属</a></li>
                        <li class="rnav3"><a href="jilu.php" target="_blank">生活记录</a></li>
                        <li class="rnav4"><a href="yinyue.php" target="_blank">音乐欣赏</a></li>
                    </ul>
                </div>
  </div> </div>
    </article>
<footer>
  <p>Design by 刘坤</p>
</footer>
</body>
</html>
