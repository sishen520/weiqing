


<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
        <meta name="baidu-site-verification" content="XDk93xXVav" />
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="Keywords" content="魏晴，小2小2小小巫" /><meta name="Description" content="魏晴" /><link href="css/index.css" rel="stylesheet" /><link href="./css/base.css" rel="stylesheet" /><link href="./css/style.css" rel="stylesheet" />
    <title>你无法体会我的孤独</title>
    <link href="./css/new.css" rel="stylesheet" />
    <link rel="shortcut icon" href="images/tubiao.ico">
<title>

</title></head>
<body>
    <header>
        <h1><a href="/">WuGuoGeng's Blog</a></h1>
        <p>趁我们都还年轻,多欣赏下沿途的风景，不要错过了流年里温暖的人和物....</p>
    </header>
    <!--nav begin-->
    <div id="nav">
        <ul>
            <li><a href="/">首页</a></li>
            <li><a href="jilu.php">生活记录</a></li>
            <li><a href="photo.php">相册</a></li>
            <li><a href="about.php">关于我</a></li>
            <li><a href="messageBoard.php">留言板</a></li>
            <li><a href="yinyue.php" target="_blank">音乐欣赏</a></li>
        </ul>
    </div>
    <!--nav end-->
    <article class="blogs">
        <div id="l_box">
          
             <div style="line-height:33px">
                 <p class="p1">现在的位置：<a href="/">首页</a> &gt;<a href="jilu.php">生活记录</a> &gt;文章</p>
                    </div>    

    <article class="blogs">
        <div class="index_about">
            <h2 class="c_titile">【死神】你无法体会我的孤独。</h2>
    <p class="box_c"><span class="d_time">发布时间：2016-04-27</span><span>编辑：刘坤</span><span>QQ：<a target='_blank' href='http://wpa.qq.com/msgrd?v=3&uin=1218639019&site=qq&menu=yes'>1218639019</a></span></p>

            <ul class="infos">

                <audio src="http://www.weiqing.esy.es/sound/夜的钢琴曲5.mp3"  controls autoplay='autoplay'></audio><br>
                                     <!--音乐名：夜的钢琴曲5，作者：石进-->
<p>
	<span style="white-space:nowrap;">        我曾经在游戏里跟人骂的狗血喷头，有人误解我我会冲上去跟他吵的天昏地暗来证明自己做的并没有错。如<br>今，我却不想说一句话。因为我不知道如何去说。不想做过多的解释，因为我觉得，所有的事都是上天注定的。<br>你和某一个人的关系如何，不是一两句话就可以改变的。即便可以改变些什么，已然已经疏远了。<br>

</span>
</p>
<p>
    <span style="white-space:nowrap;">  
                高二时我曾一度感觉自己要撑不下去了。我也会问自己追求的自己想要的到底是什么，那个时候答案可能是不<br>想孤身一人。从那时起我开始去背《般若波罗蜜多心经》，我看不懂，我就去百度看注释。但是有一句我始终懂得，<br>“色不异空，空不异色；色即是空，空即是色”。也是从那时开始，我开始看言情小说，借人家的杂志来看，独木<br>舟，韩十三，杨千紫，乐小米。从《80后》看到《花火》《飞魔幻》《飞言情》我尤其喜欢独木舟的小说，因为大<br>多都是悲剧结尾。<br>

        
    </span>    
</p>
<p>
    <span style="white-space:nowrap;">  
       终于，到最后和朋友一起走在大街上，朋友告诉我，哎刚才走过去那个妹子真漂亮，我稍微迟滞了一下，“哪<br>个？”，“就刚才从咱们身边走过去的那个”，“哦，我没看到长什么样”，到我一个人的时候可能走在街上跟人<br>面对面路过我都没认出来，有时候可能是在想事情，但是事后我也不知道自己在想什么。也或许是眼神没有焦点。<br>以至于有时候走过去了，回头看了一下，哎，那不是某某某嘛。然而都已经走过去了。。<br>
 
        
    </span>    
</p> 
<p>
    <span style="white-space:nowrap;">  
        后来我开始刷存在感，在空间发说说自恋引来一阵嘲讽，在空间发漂亮女孩的照片，有的我甚至见都没有见过。<br>只是想刷出来一点存在感，让我知道我不孤单。qq空间留言板里面的留言不知道多久没有更新过，我每次进空间总<br>是去看看留言审核，看一下会不会有其他陌生人跟我留言。以前还可以看到有一些人刷广告留言，如今每次打开留<br>言审核，0的数字已不知道多久没变过了。<br>

        
    </span>    
</p> 
                
<p>
    <span style="white-space:nowrap;">  
         我说过要变成一个没心没肺什么都不在乎的人，我说过无论在什么时候都不去做一些没必要的没结果的解释，<br>我说过要努力做到不因外部因素干扰自己的内心。不去为某个事情争个你死我活。所以后来我只能说，“就这样<br>吧”“可以”“知道了”“不想说了”“算了吧”。<br>

        
    </span>    
</p> 
<p>
    <span style="white-space:nowrap;">  
         你无法体会我的孤独，因为你随便一条说说可能就有十几个人评论，因为你可能跟一个人聊到顾不上回复其他<br>人。而我可能只是对着手机在发呆而已。<br>

        
    </span>    
</p> 
<p>
    <span style="white-space:nowrap;">  
           我喜欢清净，却害怕孤独；我不善于表达，故讨厌被人误解；我总是刷存在感，因为这样会觉有人在乎我、有<br>人关注我；我最近总在想“不以物喜，不以己悲”这两句词，我可能会朝着这个方向走，希望如此可以练就一颗强<br>大的内心。<br>

        
    </span>    
</p>   
<p>
    <span style="white-space:nowrap;">  
         感谢看到这里的朋友们。我是刘坤。<br>       
    </span>    
</p>
<p>
    <span style="white-space:nowrap;">  
        <font face=Times New Roman> <a href="http://www.sishen.ga" target="_blank"><u>http://www.sishen.ga/</u></a>  </font>     
    </span>    
</p> 

                <div><br /></div>
            </ul>
            <div class="keybq">
                <p><span>我是刘坤，我为自己代言！</span></p>

            </div>
            <div class="ad"></div>
            <div class="nextinfo">
                <p>上一篇：没有了</p>
                <p>下一篇：<a href='jilu-03.php'>如果这个城市只剩我和你</a></p><br>
            </div>

          <TABLE borderColor=green  height=0 width=1028 cellPadding=0 width=100 align=center border=1>
<TBODY>
<TR>
<TD>
    
</TD></TR></TBODY></TABLE><br>
            

<!-- 评论代码 -->
            
        </div>
        
        
        
                <aside class="right">

            <div class="blank"></div>


        </aside>
    </article>

        </div>
        <div id="r_box">
            <aside class="right">
                <div class="rnav">
                    <ul>
                        <li class="rnav1"><a href="http://vip.xcsee.cn" target="_blank">死神影视</a></li>
                        <li class="rnav2"><a href="http://www.weiqing.cf/weiqing.html" target="_blank">魏晴专属</a></li>
                        <li class="rnav3"><a href="jilu.php" target="_blank">生活记录</a></li>
                        <li class="rnav4"><a href="yinyue.php" target="_blank">音乐欣赏</a></li>
                    </ul>
                </div>
    </article>
<footer>
  <p>Design by 刘坤</p>
</footer>
</body>
</html>