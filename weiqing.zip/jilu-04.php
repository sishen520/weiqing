


<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
        <meta name="baidu-site-verification" content="XDk93xXVav" />
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="Keywords" content="魏晴，小2小2小小巫" /><meta name="Description" content="魏晴" /><link href="css/index.css" rel="stylesheet" /><link href="./css/base.css" rel="stylesheet" /><link href="./css/style.css" rel="stylesheet" />
    <title>这是一种什么样的体验</title>
    <link href="./css/new.css" rel="stylesheet" />
    <link rel="shortcut icon" href="images/tubiao.ico">
<title>

</title></head>
<body>
    <header>
        <h1><a href="/">魏晴</a></h1>
        <p>趁我们都还年轻,多欣赏下沿途的风景，不要错过了流年里温暖的人和物....</p>
    </header>
    <!--nav begin-->
    <div id="nav">
        <ul>
            <li><a href="/">首页</a></li>
            <li><a href="jilu.php">生活记录</a></li>
            <li><a href="photo.php">相册</a></li>
            <li><a href="about.php">关于我</a></li>
            <li><a href="messageBoard.php">留言板</a></li>
            <li><a href="yinyue.php" target="_blank">音乐欣赏</a></li>
        </ul>
    </div>
    <!--nav end-->
    <article class="blogs">
        <div id="l_box">
          
             <div style="line-height:33px">
                 <p class="p1">现在的位置：<a href="/">首页</a> &gt;<a href="jilu.php">生活记录</a> &gt;文章</p>
                    </div>    

    <article class="blogs">
        <div class="index_about">
            <h2 class="c_titile">这是一种什么样的体验</h2>
            <p class="box_c"><span class="d_time">发布时间：2016-04-29 01:00:05</span><span>编辑：刘坤</span><span>QQ：<a target='_blank' href='http://wpa.qq.com/msgrd?v=3&uin=1218639019&site=qq&menu=yes'>1218639019</a></span></p>

            <ul class="infos">

                              <audio src="http://jx.xcsee.cn/music/neverforget.mp3"  controls autoplay='autoplay'></audio><br>
                                  <!--音乐名：neverforget -->
<p>
	<span style="white-space:nowrap;">关注你，所以总去看你的动态。<br>

</span>
</p>
<p>
	<span style="white-space:nowrap;">给你留言证明我真的来过。<br>

</span>
</p>


                <img src="images/liuyan.png" />
                <br><br><br>
             
<p>
	<span style="white-space:nowrap;">自己喜欢的人@#￥%…*是一种怎么样体验。<br>

</span>
</p>
<p>
	<span style="white-space:nowrap;">南无阿弥陀佛<br>

</span>
</p>

                <div><br /></div>
            </ul>
            <div class="keybq">
                <p><span>我是刘坤，我为自己代言！</span></p>

            </div>
            <div class="ad"></div>
            <div class="nextinfo">
                <p>上一篇：<a href='jilu-03.php'>如果这个城市只剩我和你</a></p>
                <p>下一篇：<a href='jilu-05.php'>你一直在向前走，从未回头</a></p><br>
            </div>

          <TABLE borderColor=green  height=0 width=1028 cellPadding=0 width=100 align=center border=1>
<TBODY>
<TR>
<TD>
    
</TD></TR></TBODY></TABLE><br>
            

<!-- 评论代码 -->
            
        </div>
        
        
        
                <aside class="right">

            <div class="blank"></div>


        </aside>
    </article>

        </div>
        <div id="r_box">
            <aside class="right">
                <div class="rnav">
                    <ul>
                        <li class="rnav1"><a href="http://vip.xcsee.cn" target="_blank">死神影视</a></li>
                        <li class="rnav2"><a href="http://www.weiqing.cf/weiqing.html" target="_blank">魏晴专属</a></li>
                        <li class="rnav3"><a href="jilu.php" target="_blank">生活记录</a></li>
                        <li class="rnav4"><a href="yinyue.php" target="_blank">音乐欣赏</a></li>
                    </ul>
                </div>
    </article>
<footer>
  <p>Design by 刘坤</p>
</footer>
</body>
</html>