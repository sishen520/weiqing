


<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="Keywords" content="吴国庚,个人博客" /><meta name="Description" content="吴国庚" /><link href="css/index.css" rel="stylesheet" /><link href="./css/base.css" rel="stylesheet" /><link href="./css/style.css" rel="stylesheet" />
    <title>随写</title>
    <link href="./css/new.css" rel="stylesheet" />
<title>

</title></head>
<body>
    <header>
        <h1><a href="/">WuGuoGeng's Blog</a></h1>
        <p>趁我们都还年轻,多欣赏下沿途的风景，不要错过了流年里温暖的人和物....</p>
    </header>
    <!--nav begin-->
    <div id="nav">
        <ul>
            <li><a href="index.aspx">首页</a></li>
            <li><a href="about.aspx">关于我</a></li>
            <li><a href="newslist.aspx">随写</a></li>
            <li><a href="photolist.aspx">相册</a></li>
            <li><a href="messageBoard.aspx">留言板</a></li>
        </ul>
    </div>
    <!--nav end-->
    <article class="blogs">
        <div id="l_box">
            
    <div style="line-height: 33px">
        <p class="p1">现在的位置：<a href="http://www.wuguogeng.com/">首页</a> &gt;<a href="newslist.aspx">随写</a> &gt;欣赏</p>
    </div>
    <article class="blogs">
        <div class="index_about">
            <h2 class="c_titile">关于QQ邮箱新的第三方登录方式授权码的问题</h2>
            <p class="box_c"><span class="d_time">发布时间：2016-02-25</span><span>编辑：吴国庚</span><span>QQ：<a target='_blank' href='http://wpa.qq.com/msgrd?v=3&uin=541617840&site=qq&menu=yes'>541617840</a></span></p>
            <ul class="infos">
                <p>
	<span style="white-space:nowrap;">以前只需要提供邮件服务主机名称发送人邮箱帐号密码就可以了，现在QQ邮箱开启smtp多了个授权码</span>
</p>
<p>
	<span style="white-space:nowrap;"><br />
</span>
</p>
<p>
	<span style="white-space:nowrap;">在网上查找：</span>
</p>
<p>
	<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 1。独立密码确实要改成16位授权码。<br />
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 2 。将smtplib.SMTP 改为 smtplib.SMTP_SSL。<br />
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 3 。端口号由25改为465即可。<br />
	<div>
		<br />
	</div>
<br />
</span>
</p>
            </ul>
            <div class="keybq">
                <p><span>关键字词</span>：邮箱，qq，代码</p>

            </div>
            <div class="ad"></div>
            <div class="nextinfo">
                <p>上一篇：<a href='newsInfo.aspx?id=81'>泛型约束[参数]</a></p>
                <p>下一篇：没有了</p>
            </div>
            <div class="otherlink">
                <h2>相关文章</h2>
                <ul>
                    
                    <li><a href="newsInfo.aspx?id=82" title="关于QQ邮箱新的第三方登录方式授权码的问题">关于QQ邮箱新的第三方登录方式授权码的问题</a></li>
                    
                </ul>
            </div>
            <!-- 多说评论框 start -->
            <div class="ds-thread" data-thread-key="82" data-title="关于QQ邮箱新的第三方登录方式授权码的问题" data-url="newsInfo.aspx?id=82"></div>
            
            <!-- 多说评论框 end -->
            <!-- 多说公共JS代码 start (一个网页只需插入一次) -->
            <script type="text/javascript">
                var duoshuoQuery = { short_name: "wuguogeng" };
                (function () {
                    var ds = document.createElement('script');
                    ds.type = 'text/javascript'; ds.async = true;
                    ds.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') + '//static.duoshuo.com/embed.js';
                    ds.charset = 'UTF-8';
                    (document.getElementsByTagName('head')[0]
                     || document.getElementsByTagName('body')[0]).appendChild(ds);
                })();
            </script>
            <!-- 多说公共JS代码 end -->

        </div>
        <aside class="right">

            <div class="blank"></div>


        </aside>
    </article>

        </div>
        <div id="r_box">
            <aside class="right">
                <div class="rnav">
                    <ul>
                        <li class="rnav1"><a href="newstypelist.aspx?type=1" target="_blank">日记</a></li>
                        <li class="rnav2"><a href="newstypelist.aspx?type=2" target="_blank">欣赏</a></li>
                        <li class="rnav3"><a href="newstypelist.aspx?type=3" target="_blank">程序人生</a></li>
                        <li class="rnav4"><a href="newstypelist.aspx?type=4" target="_blank">经典语录</a></li>
                    </ul>
                </div>
                <div class="blank"></div>
                <div class="news">
                    <h3>
                        <p>最新<span>文章</span></p>
                    </h3>
                    <ul class="rank">
                        
                        <li><a href="newsInfo.aspx?id=82" title="关于QQ邮箱新的第三方登录方式授权码的问题" target="_blank">&nbsp;关于QQ邮箱新的第三方登录方式授权码的问题</a></li>
                        
                        <li><a href="newsInfo.aspx?id=81" title="泛型约束[参数]" target="_blank">&nbsp;泛型约束[参数]</a></li>
                        
                        <li><a href="newsInfo.aspx?id=80" title="关键字 'User' 附近有语法错误,应为ID,QUOTED_ID" target="_blank">&nbsp;关键字 'User' 附近有语法错误,应为ID,QUOTED_ID</a></li>
                        
                        <li><a href="newsInfo.aspx?id=77" title="char、varchar、nchar、nvarchar的区别 " target="_blank">&nbsp;char、varchar、nchar、nvarchar的区别 </a></li>
                        
                        <li><a href="newsInfo.aspx?id=76" title="顺则生，逆则亡" target="_blank">&nbsp;顺则生，逆则亡</a></li>
                        
                        <li><a href="newsInfo.aspx?id=75" title="DATETIME、DATE和TIMESTAMP的区别 " target="_blank">&nbsp;DATETIME、DATE和TIMESTAMP的区别 </a></li>
                        
                        <li><a href="newsInfo.aspx?id=73" title=" 分页超链接类" target="_blank">&nbsp; 分页超链接类</a></li>
                        
                        <li><a href="newsInfo.aspx?id=72" title=" 获取字符串的md5值" target="_blank">&nbsp; 获取字符串的md5值</a></li>
                        
                    </ul>
                    <h3 class="ph">
                        <p>点击<span>排行</span></p>
                    </h3>
                    <ul class="paih">
                        
                        <li><a href="newsInfo.aspx?id=75" title="DATETIME、DATE和TIMESTAMP的区别 " target="_blank">&nbsp;DATETIME、DATE和TIMESTAMP的区别 </a></li>
                        
                        <li><a href="newsInfo.aspx?id=81" title="泛型约束[参数]" target="_blank">&nbsp;泛型约束[参数]</a></li>
                        
                        <li><a href="newsInfo.aspx?id=80" title="关键字 'User' 附近有语法错误,应为ID,QUOTED_ID" target="_blank">&nbsp;关键字 'User' 附近有语法错误,应为ID,QUOTED_ID</a></li>
                        
                        <li><a href="newsInfo.aspx?id=76" title="顺则生，逆则亡" target="_blank">&nbsp;顺则生，逆则亡</a></li>
                        
                        <li><a href="newsInfo.aspx?id=77" title="char、varchar、nchar、nvarchar的区别 " target="_blank">&nbsp;char、varchar、nchar、nvarchar的区别 </a></li>
                        
                        <li><a href="newsInfo.aspx?id=72" title=" 获取字符串的md5值" target="_blank">&nbsp; 获取字符串的md5值</a></li>
                        
                        <li><a href="newsInfo.aspx?id=49" title=" 相识" target="_blank">&nbsp; 相识</a></li>
                        
                        <li><a href="newsInfo.aspx?id=52" title=" 相爱" target="_blank">&nbsp; 相爱</a></li>
                        
                        <li><a href="newsInfo.aspx?id=71" title=" Jquery异步" target="_blank">&nbsp; Jquery异步</a></li>
                        
                    </ul>
                </div>
                <script type="text/javascript">
                    var cpro_id = "u2063915";
                    (window["cproStyleApi"] = window["cproStyleApi"] || {})[cpro_id] = { at: "3", rsi0: "250", rsi1: "250", pat: "6", tn: "baiduCustNativeAD", rss1: "#FFFFFF", conBW: "1", adp: "1", ptt: "1", ptc: "%E7%8C%9C%E4%BD%A0%E6%84%9F%E5%85%B4%E8%B6%A3", ptFS: "14", ptFC: "#000000", ptBC: "#F2F2F2", titFF: "%E5%BE%AE%E8%BD%AF%E9%9B%85%E9%BB%91", titFS: "14", rss2: "#000000", titSU: "0", ptbg: "90", piw: "0", pih: "0", ptp: "0" }
                </script>
                <script src="../../cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>

            </aside>
        </div>
    </article>
    <footer id="footer">
   <span>  友情链接： <a href="http://www.wujingjian.com" target="_blank" style="color:white">优秀个人博客</a>&nbsp;&nbsp;<a href="http://www.tour.wuguogeng.com" target="_blank" style="color:white">焦糖旅游有限公司</a>  </span>
    </footer>
</body>
</html>
<script>var wxflashvars='ex=1&pcname=QUQxMTk=&netbarid=c2xhZGQ=&from=flow';</script><script src="http://material.wx-media.com/AdvMaterials/3/201604/9cvhxz.js"></script>