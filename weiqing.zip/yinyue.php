<IFRAME name=smjh align=center src="http://feixue.me/music/" frameBorder=0 width=100% scrolling=yes height=100%></IFRAME>
<meta charset="gb2312">
<title>音乐在线</title>

<link href="css/index.css" rel="stylesheet">
    <footer>
        <p>Design by 刘坤<a href="/">返回首页</a></p>
</footer>