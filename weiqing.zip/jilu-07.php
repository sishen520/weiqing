


<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <meta name="baidu-site-verification" content="XDk93xXVav" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="Keywords" content="魏晴，魏晴，魏晴，魏晴，小2小2小小巫，亲爱的，你就这样丢下我了，亲爱的，别留我一个人在这里" /><meta name="Description" content="魏晴" /><link href="css/index.css" rel="stylesheet" /><link href="./css/base.css" rel="stylesheet" /><link href="./css/style.css" rel="stylesheet" />
    <title>亲爱的，别留我一个人在这里</title>
    <link href="./css/new.css" rel="stylesheet" />
    <link rel="shortcut icon" href="images/tubiao.ico">
<title>

</title></head>
<body>
    <header>
        <h1><a href="/">魏晴</a></h1>
        <p>趁我们都还年轻,多欣赏下沿途的风景，不要错过了流年里温暖的人和物....</p>
    </header>
    <!--nav begin-->
    <div id="nav">
        <ul>
            <li><a href="/">首页</a></li>
            <li><a href="jilu.php">生活记录</a></li>
            <li><a href="photo.php">相册</a></li>
            <li><a href="about.php">关于我</a></li>
            <li><a href="messageBoard.php">留言板</a></li>
            <li><a href="yinyue.php" target="_blank">音乐欣赏</a></li>
        </ul>
    </div>
    <!--nav end-->
    <article class="blogs">
        <div id="l_box">
          
             <div style="line-height:33px">
                 <p class="p1">现在的位置：<a href="/">首页</a> &gt;<a href="jilu.php">生活记录</a> &gt;文章</p>
                    </div>    

    <article class="blogs">
        <div class="index_about">
            <h2 class="c_titile">亲爱的，别留我一个人在这里</h2>
            <p class="box_c"><span class="d_time">发布时间：2016-06-02 15:15:35</span><span>编辑：刘坤</span><span>QQ：<a target='_blank' href='http://wpa.qq.com/msgrd?v=3&uin=1218639019&site=qq&menu=yes'>1218639019</a></span></p>

            <ul class="infos">

                              <audio src="http://jx.xcsee.cn/music/starrystarrynight.mp3"  controls autoplay='autoplay'></audio><br>
                               <!--音乐名：starrystarrynight -->
<p>
	<span style="white-space:nowrap;"><br>

</span>
</p>
                <p>亲爱的，我们认识三年了，整整三年了<br>
&nbsp;&nbsp;&nbsp;&nbsp;可你就在这三年的终点把我删掉了。<br>
&nbsp;&nbsp;&nbsp;&nbsp;你有男朋友了，我尽量的不去打扰你。<br>
&nbsp;&nbsp;&nbsp;&nbsp;我连给你留言都不敢，怕你男朋友误会，怕给你们带来麻烦。<br>
&nbsp;&nbsp;&nbsp;&nbsp;可你依旧把我删掉了<br>
&nbsp;&nbsp;&nbsp;&nbsp;就在我认为我快要习惯快要淡忘掉你有男朋友带给我的忧伤之际。<br>
&nbsp;&nbsp;&nbsp;&nbsp;就在我在空间说我要努力为以后努力的时候。<br>
&nbsp;&nbsp;&nbsp;&nbsp;你像是故意的，<br>
&nbsp;&nbsp;&nbsp;&nbsp;你不会不知道我有多难过。<br>
&nbsp;&nbsp;&nbsp;&nbsp;可你就是这样把我丢下了。<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;我不知道你什么感受<br>
&nbsp;&nbsp;&nbsp;&nbsp;我不知道你会不会有那么一丝一毫的难过，<br>
&nbsp;&nbsp;&nbsp;&nbsp;毕竟你正沉浸正享受爱的温暖，<br>
&nbsp;&nbsp;&nbsp;&nbsp;如果你能为我稍微想那么一丁点<br>
&nbsp;&nbsp;&nbsp;&nbsp;你就不会把我删掉<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;我不敢对你表白，<br>
&nbsp;&nbsp;&nbsp;&nbsp;我多害怕失去你，<br>
&nbsp;&nbsp;&nbsp;&nbsp;你知道我爱的是你，<br>
&nbsp;&nbsp;&nbsp;&nbsp;从一开始到现在我爱了你三年你不可能不知道。<br>
&nbsp;&nbsp;&nbsp;&nbsp;可你依旧在我最无助最难受的时间<br>
&nbsp;&nbsp;&nbsp;&nbsp;就这样真真切切把我一个人留在这里了，<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;都怪我做的不好，<br>
&nbsp;&nbsp;&nbsp;&nbsp;怪我可能做的一些事让你觉得我多情滥情，<br>
&nbsp;&nbsp;&nbsp;&nbsp;毕竟我是双鱼座，而你，恰好是处女座。<br>
&nbsp;&nbsp;&nbsp;&nbsp;但是这么多年，<br>
&nbsp;&nbsp;&nbsp;&nbsp;亲爱的，我只爱过你。<br></p>
                &nbsp;&nbsp;&nbsp;&nbsp;<img src='images/weiqing/kongjian.png' />
                <div><br /></div>
            </ul>
            <div class="keybq">
                <p><span>我是刘坤，我为自己代言！</span></p>

            </div>
            <div class="ad"></div>
            <div class="nextinfo">
                <p>上一篇：无</p>
                <p>下一篇：<a href='jilu-06.php'>我亦曾爱过你</a></p><br>
            </div>

          <TABLE borderColor=green  height=0 width=1028 cellPadding=0 width=100 align=center border=1>
<TBODY>
<TR>
<TD>
    
</TD></TR></TBODY></TABLE><br>
            
<!-- 评论代码 -->
            
        </div>
        
        
        
                <aside class="right">

            <div class="blank"></div>


        </aside>
    </article>

        </div>
        <div id="r_box">
            <aside class="right">
                <div class="rnav">
                    <ul>
                        <li class="rnav1"><a href="http://vip.xcsee.cn" target="_blank">死神影院</a></li>
                        <li class="rnav2"><a href="http://www.weiqing.cf/weiqing.html" target="_blank">魏晴专属</a></li>
                        <li class="rnav3"><a href="jilu.php" target="_blank">生活记录</a></li>
                        <li class="rnav4"><a href="yinyue.php" target="_blank">音乐欣赏</a></li>
                    </ul>
                </div>
    </article>
<footer>
  <p>Design by 刘坤</p>
</footer>
</body>
</html>