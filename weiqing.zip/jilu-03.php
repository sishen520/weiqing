


<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
        <meta name="baidu-site-verification" content="XDk93xXVav" />
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><meta name="Keywords" content="魏晴，小2小2小小巫" /><meta name="Description" content="魏晴" /><link href="css/index.css" rel="stylesheet" /><link href="./css/base.css" rel="stylesheet" /><link href="./css/style.css" rel="stylesheet" />
    <title>如果这个城市只剩我和你</title>
    <link href="./css/new.css" rel="stylesheet" />
    <link rel="shortcut icon" href="images/tubiao.ico">
<title>

</title></head>
<body>
    <header>
        <h1><a href="/">WuGuoGeng's Blog</a></h1>
        <p>趁我们都还年轻,多欣赏下沿途的风景，不要错过了流年里温暖的人和物....</p>
    </header>
    <!--nav begin-->
    <div id="nav">
        <ul>
            <li><a href="/">首页</a></li>
            <li><a href="jilu.php">生活记录</a></li>
            <li><a href="photo.php">相册</a></li>
            <li><a href="about.php">关于我</a></li>
            <li><a href="messageBoard.php">留言板</a></li>
            <li><a href="yinyue.php" target="_blank">音乐欣赏</a></li>
        </ul>
    </div>
    <!--nav end-->
    <article class="blogs">
        <div id="l_box">
          
             <div style="line-height:33px">
                 <p class="p1">现在的位置：<a href="/">首页</a> &gt;<a href="jilu.php">生活记录</a> &gt;文章</p>
                    </div>    

    <article class="blogs">
        <div class="index_about">
            <h2 class="c_titile">《如果这个城市只剩我和你》作者：墨小芭</h2>
    <p class="box_c"><span class="d_time">发布时间：2016-04-28</span><span>编辑：刘坤</span><span>QQ：<a target='_blank' href='http://wpa.qq.com/msgrd?v=3&uin=1218639019&site=qq&menu=yes'>1218639019</a></span></p>

            <ul class="infos">

                              <audio src="http://jx.xcsee.cn/music/zhuiguangzhe.mp3"  controls autoplay='autoplay'></audio><br>
                                  <!--音乐名：追光者-->
<p>
	<span style="white-space:nowrap;"> 我在网络上看到这样一句话，是说，所谓的成熟就是，曾经怎样努力都得不到的，现在不想要了。<br>

</span>
</p>
<p>
    <span style="white-space:nowrap;">  
 顾晨曦，如果这句话不是哪个没有道德的人写来骗稿费的，那么此刻的我一定是被注入了苍老的灵魂，所以才<br>会对你，选择了放手。<br>

        
    </span>    
</p>
                <h3>001 它怎么会崩溃呢?哦，这个啊，它的生活压力太大了</h3>
<p>
    <span style="white-space:nowrap;">  
第一次遇见顾晨曦的时候，他留着浓密但并不惹人嫌的胡楂，戴一副正正经经的黑框眼镜，嘴里叼着烟，苍白<br>且修长的手指在黑色的键盘上敲了几下，告诉我，它崩溃了。 
        
    </span>    
</p> 
<p>
    <span style="white-space:nowrap;">  
  “它”指的是我的笔记本电脑，又笨又重但跟了我三年。
        
    </span>    
</p> 
                
<p>
    <span style="white-space:nowrap;">  
我虚心请教：“它怎么崩溃了呢?”
        
    </span>    
</p> 
<p>
    <span style="white-space:nowrap;">  
顾晨曦抬眉看了我一眼，说：“哦，这个啊，它的生活压力太大了。”
        
    </span>    
</p> 
<p>
    <span style="white-space:nowrap;">  
说完他自顾自地笑了起来，声音爽朗得很。但平心而论，他的话真的没什么好笑，还有点冷，所以我只是象征<br>性地抽搐了一下嘴角，希望他能给予一个好的解决方式。
        
    </span>    
</p>   
<p>
    <span style="white-space:nowrap;">  
那天的阳光有些晃眼，刺目的白成群结队地扑棱到雪白墙面上，过滤掉七分灼热，余下的三分温暖爬上顾晨曦<br>的额。他眉头皱着，胡楂上满是和煦的光斑，一粒一粒看起来分外抢眼。   
    </span>    
</p>
                <p>
    <span style="white-space:nowrap;">  
作为一个电脑盲，我能够做的，只有在他埋头鼓捣我电脑的时侯傻愣愣地站在一旁看着。二十分钟后，顾晨曦<br>朝窗外望了一眼，然后跳下椅子快步走了出去。
       
    </span>    
</p>
                <p>
    <span style="white-space:nowrap;">  
我又傻愣愣地在维修部站了约三分钟，推门进来的却不是顾晨曦了，而是一个三十岁上下的中年男人，想必是<br>这里的老板没有错。哦对了，我忘了说，根据目测，顾晨曦的年龄顶多比我大个两三岁，是可以用少年两字形容的<br>小青年，所以我才对他年轻的胡楂那么感兴趣。
      
    </span>    
</p>
                <p>
    <span style="white-space:nowrap;">  
那男人看了看我，又看了看我的电脑，抬手一拍脑门，大喊不妙：“糟了，你的电脑一定也是遭到了那小子的<br>毒手，里面有重要的文件吗?”
      
    </span>    
</p>
                <p>
    <span style="white-space:nowrap;">  
我点点头。
   
    </span>    
</p>
                <p>
    <span style="white-space:nowrap;">  
中年男人怜悯地看着我说：“那真是不幸，凡是遭过顾晨曦毒手的电脑总没有好下场，小姑娘，你节哀顺变。”
    </span>    
</p>
                <p>
    <span style="white-space:nowrap;">  
阳光继续扑棱着照进来，直直地落在我的天灵盖上。
    </span>    
</p>
                <p>
    <span style="white-space:nowrap;">  
据中年男人回忆，在十二天前，顾晨曦来这里安装软件时不小心被他彻底删除了一个图片文件夹，这让顾晨曦<br>“兽性大发”了，他将店老板从祖宗骂到重孙子之后抱着电脑泪奔着跑了出去。
    </span>    
</p><p>
    <span style="white-space:nowrap;">  
再回来时，顾晨曦就练就了一手绝活，便是但凡经过他手的电脑准保不住任何一个文件。
    </span>    
</p><p>
    <span style="white-space:nowrap;">  
店老板苦着脸告诉我，我十分荣幸地成为了第十六个“一不小心就羊入虎口”的倒霉客人，并向我表达了衷心<br>的歉意以及想要关门大吉的未来规划——顾晨曦总有办法在老板去吃午饭时潜进店来，像一个固执的且迷恋着搞恶<br>作剧的孩子。
    </span>    
</p><p>
    <span style="white-space:nowrap;">  
这种幼稚的报复行为在我看来真是十分的孩子气，不禁在心里感慨着老板没有报警的善举，并诅咒着顾晨曦这<br>个倒霉孩子，不过后来我听说，那个文件夹里放着的是顾晨曦和女朋友在一起时拍摄的全部照片。
    </span>    
</p><p>
    <span style="white-space:nowrap;">  
再后来我还听说，那个文件夹里被他视若珍宝的女孩子，已经不在人世。
    </span>    
</p><p>
    <span style="white-space:nowrap;">  
以上两条，导致我不会继续在熬夜赶稿的深夜里诅咒他一辈子吃泡面找不到调味包。
    </span>    
</p>
                <p>
    <span style="white-space:nowrap;">  
事实上自从做枪手以来，我还真就没有过一个靠文字吃饭的人该有的自觉——熬夜与吃泡面。
    </span>    
</p><p>
    <span style="white-space:nowrap;">  
泡面我倒是时常吃，熬夜却从未有过。
    </span>    
</p><p>
    <span style="white-space:nowrap;">  
拜顾晨曦所赐，我觉得自己对一份来之不易的职业该有的使命感从心灵上和肉体上都得到了一次升华。
    </span>    
</p><p>
    <span style="white-space:nowrap;">  
这份工作是陆小肥隔着千山万水为我谋来的，他在鹿特丹喝着香味浓郁的蓝山告诉我，他要回国了，在这之前，<br>他为我找到一份薪资丰厚且低调的工作，那就是为一个笔名为艾希的青年女作家做枪手。
    </span>    
</p>
                <p>
    <span style="white-space:nowrap;">  
这果然是一份低调的工作，我十分感谢陆小肥。
    </span>    
</p>
                <p>
    <span style="white-space:nowrap;">  
陆小肥其实不叫陆小肥，顾名思义，是因为他身上的多余脂肪堆积得太厚才得来这么个名字，他本名叫陆向北。
    </span>    
</p><p>
    <span style="white-space:nowrap;">  
陆向北在回国前给我打了个越洋电话，他说：“周晓啊，这么多年了，你还记不记得我说过要娶你来着?”
    </span>    
</p>
                
                
                <h3> 002 当陆小肥还是当年的陆小肥，周晓却早已经不是当初的周晓了</h3>

十年了，我又见到陆小肥，他已经瘦得没有个陆小肥的样子了。所以说时间真是世界上最奇妙的东西，将一个肥头大耳的小朋友一点一点塑造成颇具偶像气质的美少年。<br>

&nbsp;&nbsp;&nbsp;&nbsp;不过我仍是觉得陆小肥没有变，他还爱眯缝着眼睛笑，那种略带青涩的让人觉得舒服的笑，他还爱问“你想吃点什么啊”。<br>

&nbsp;&nbsp;&nbsp;&nbsp;陆向北站在缓慢移动的白云下这样问的时候，我才发觉原来漫漫十年也不过是弹指一瞬，此刻的陆向北仿佛又变回七岁那年的陆小肥，吸着鼻涕跟在我的屁股后面追着问我“周晓周晓，你想吃点什么啊”，如此看来，时间也没有我以为的那么奇妙。<br>

&nbsp;&nbsp;&nbsp;&nbsp;陆小肥说：“周晓你还是没有变啊，瘦得跟个小鸡仔似的。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;我笑笑，并未说话。陆向北哪里知道，变与不变跟胖瘦高矮本就没有半分的关系，如果一定要说哪里变了，我也未必说得清楚，但是我知道以前的周晓不会失眠，不会酗酒，不会一整个夜晚都揪着一颗心凶猛地吸着烟。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我想如果陆向北再早些回来就好了，说不定可以见到之前的我，因为这之后他都不会再遇见了。<br>

&nbsp;&nbsp;&nbsp;&nbsp;陆向北回国后除了喜欢带着我到处吃饭，还喜欢带着我去给儿子买玩具和零食。儿子是一只很有体积感的萨摩耶，陆向北右手牵着儿子，左边跟着我，十分和谐地出入于各种各样的特色饭馆。<br>

&nbsp;&nbsp;&nbsp;&nbsp;半个月之后，儿子突然严重腹泻，陆向北也跟风严重腹泻，只有我一个人金刚不倒活蹦乱跳。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我只好胡乱地找片药喂陆向北服下，无奈不知道儿子可不可以食用人类的药物，于是只好牵着儿子去寻求兽医的帮助。<br>

&nbsp;&nbsp;&nbsp;&nbsp;就这样，我又见到顾晨曦。<br>

&nbsp;&nbsp;&nbsp;&nbsp;他的胡楂剃得十分干净，露出光洁消瘦的下巴，还穿上了洁白如新的白大褂。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我憋足了火气瞪了他一眼，别以为你穿上白大褂我就不知道你是谁。<br>

&nbsp;&nbsp;&nbsp;&nbsp;顾晨曦扶了扶眼镜扫了我一眼，就那么一眼，半分熟稔都没有的一眼，然后，他弯下腰去同儿子打招呼，他说：“嘿，你的生活压力也不小吧。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;得，这厮压根就不记得我是那十六个倒霉蛋中的一个。<br>

&nbsp;&nbsp;&nbsp;&nbsp;可是我记得呀，可是我不是大丈夫是个小女子呀，可是我记仇呀我。所以我挺阴阳怪调地说：“它能有什么压力啊它，除了吃就是拉，除了拉就是睡，顶多是爪子贱一下，删删我电脑里的文件啊之类的。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;顾晨曦一听见电脑文件果然顿了顿抚摸儿子脑袋的手，亮闪闪的镜片后面一双迷茫的眼睛看了看我，忽然正色道：“我希望你能拥有一个饲主该具备的最起码的常识，它肯吃你为它准备的食物，是因为它对你抱有绝对的信任。你不要认为吃食只是动物的一种本能，也别以为它对你的信任就是应该，你该对驯养它这件事负责任，包括它的饮食健康。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;看来他真的是压根就不记得我了，也不知道为什么，我除了有点生气，还有点儿委屈。<br>

&nbsp;&nbsp;&nbsp;&nbsp;顾晨曦训完我之后就开始给儿子做检查，喂它吃了药，又将熊一样强壮的儿子抱上打针的大桌子，然后他回头说：“愣着干什么，过来帮忙。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;我低眉顺眼地走过去捧着儿子巨大的脚掌，低眉顺眼地看着顾晨曦为它剃掉一小块雪白的毛，儿子有气无力地被打上了吊针，我就低眉顺眼地站在一旁等着。<br>

&nbsp;&nbsp;&nbsp;&nbsp;那天的顾晨曦看起来那么刻意，刻意地剃光了胡楂，刻意把自己收拾得干干净净，刻意卖命地工作。<br>

&nbsp;&nbsp;&nbsp;&nbsp;直到儿子打完了针，直到暮色四合，顾晨曦换下白大褂，套上了一件烟灰色的外衣，他说：“一共是一百六十八块。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;我想了想，说：“我忘记带钱包了啊。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;顾晨曦默默地将儿子当做“人质”扣押在了宠物医院里，然后抓起钥匙问我：“那要不要去兜兜风啊?”<br>

&nbsp;&nbsp;&nbsp;&nbsp;我笑嘻嘻地问：“可以抵药费吗?”<br>

&nbsp;&nbsp;&nbsp;&nbsp;顾晨曦说：“可以。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;顿了顿，又说：“反正你们写字的一个个都穷得要死。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;我没答理他，径直跳上机车后座，速度太快，十分怕死的我用手圈住顾晨曦的腰，脑子里灌满隆隆的引擎声和风声。<br>

&nbsp;&nbsp;&nbsp;&nbsp;切，装什么酷，原来压根就记得我嘛，还记得我是个写稿子赚钱的穷光蛋。<br>

&nbsp;&nbsp;&nbsp;&nbsp;不过话说回来，既然知道，你为什么还要删掉我用以生存的文档啊浑蛋。<br>

&nbsp;&nbsp;&nbsp;&nbsp;一路上，我的脑子都如此不听使唤地自说自话，原来我矫情起来是如此可怕的。<br>

&nbsp;&nbsp;&nbsp;&nbsp;有月光静静地流淌，漫过快速倒退的灰色建筑，漫过路边零星地盛开着的白色花朵。那天晚上我们在愈渐凉意的风里飞速穿行了三个小时，待我们到达一片野海的时候我的发型已经被吹得十分拉风了，我想这果然是兜风啊，太兜风了。<br>

&nbsp;&nbsp;&nbsp;&nbsp;顾晨曦看着我，眼神好像不太对，他淡淡地说：“程子的骨灰就洒在这儿。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;然后他又问我：“你知道程子吗?”<br>

&nbsp;&nbsp;&nbsp;&nbsp;我点点头，我记得那个老板曾经说过，文件夹里的姑娘是叫这个名字。<br>

&nbsp;&nbsp;&nbsp;&nbsp;顾晨曦说：“嗯，她就被洒在这儿。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;海边的咸腥味儿在夜间变得更为浓烈，星辰映在灰色海面上，耳边是阵阵波涛汹涌。顾晨曦不再说话，我也很是沉默，我们就那样肩并着肩面朝大海静静地站着。<br>

&nbsp;&nbsp;&nbsp;&nbsp;像是一种对峙。<br>

&nbsp;&nbsp;&nbsp;&nbsp;快到凌晨的时候，我借着月光看向顾晨曦，他微微驼着背，好看的手指藏进牛仔裤的口袋里。我就那么看着，忽然很想走过去抱抱他。<br>

                <h3>003 陆小肥手中大耳朵的熊猫橡皮，陆向北手中芬芳的城池</h3>

&nbsp;&nbsp;&nbsp;&nbsp;儿子生病的那段时间我几乎每天都往顾晨曦的宠物之家里跑，儿子完全康复之后我照样每天往顾晨曦的宠物之家里跑，比上班打卡还准时。<br>

&nbsp;&nbsp;&nbsp;&nbsp;顾晨曦倒是没发觉我已经对他一见钟情了，他把我当做一个轻浮的穷光蛋一样讨厌着，总给我摆着一张臭脸。他好像压根就忘记了是他先说要出去兜风的，虽然我连半分女孩子该有的矜持和迟疑都没有。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我曾经问过顾晨曦：“如果这城市只剩下我和你……”<br>

&nbsp;&nbsp;&nbsp;&nbsp;顾晨曦立马打断我：“那我宁愿对着镜子喜欢我自己。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;不过我是谁啊，我是没脸没皮的穷光蛋啊，谁在乎你给不给我摆臭脸。<br>

&nbsp;&nbsp;&nbsp;&nbsp;所以我阴魂不散越挫越勇斗志昂扬。我白天到宠物之家蹲点，晚上就回家抽烟喝酒赶稿子，小日子过得兢兢业业有条不紊。<br>

&nbsp;&nbsp;&nbsp;&nbsp;周末的时候陆向北推开我的家门，被呛人的烟味逼得后退了几步，然后他隔着被新鲜空气一点一点撞开的烟雾不可思议地问：“周晓你干吗呢?”<br>

&nbsp;&nbsp;&nbsp;&nbsp;我转过头去眨巴着红通通的双眼回答：“敲字赚钱啊。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;陆向北抿了抿嘴，镇定了一下心神后快步上前一把夺过我手中的ESSE香烟，然后这个败家孩子将烟蒂连同剩下的五盒半香烟一股脑丢进了马桶里，还特别绝情地按下了冲水按钮。<br>

&nbsp;&nbsp;&nbsp;&nbsp;“陆向北你这个人渣!马桶才刚修好啊!现在又被你堵上了!”<br>

&nbsp;&nbsp;&nbsp;&nbsp;“马桶堵上了我给你修，你的问题要你自己修!”他气得直哆嗦，那气焰一下子把我给压制得连个声都不敢吭。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我是挺心虚，之前的周晓闻个二手烟都要矫情地咳嗽半天。<br>

&nbsp;&nbsp;&nbsp;&nbsp;那时候的周晓是一个大近视，可是心地却很明亮，她穿白色的T恤和干干净净的牛仔裤，晚上九点睡觉早晨七点准时起床，喝牛奶和果汁，头发在脑后扎成一个整洁利索的马尾，喜欢将帆布鞋刷得干干净净地晾晒在阳台上。<br>

&nbsp;&nbsp;&nbsp;&nbsp;至少那时候的周晓觉得，抽烟喝酒的女人简直丑死了。<br>

&nbsp;&nbsp;&nbsp;&nbsp;现在的我，正是曾经自己最最厌恶的样子。<br>

&nbsp;&nbsp;&nbsp;&nbsp;只是我忘不掉十六岁那一年的冬天，忘不掉失明半年后好不容易得以重见阳光的我见到的那一幕血红。<br>

&nbsp;&nbsp;&nbsp;&nbsp;十五岁，我与母亲在去往游乐场的途中遭遇车祸，母亲当场死亡，我被她护在怀里逃过一劫，却因为撞击到眼部导致眼角膜脱落。突如其来的意外和黑暗让我的性格变得十分孤僻，常常一个人躲在墙角或是窗帘后哭到干呕。<br>

&nbsp;&nbsp;&nbsp;&nbsp;父亲在一夜之间苍老了许多，却常常安慰我：“晓晓别怕，一旦找到适合的捐献者我们就可以做眼角膜移植手术，你还可以看见爸爸，还可以看见你曾经可以看到的一切。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;我当然相信做了近二十年医生的父亲说的话。<br>

&nbsp;&nbsp;&nbsp;&nbsp;所以一年后，当父亲激动地跑来告诉我，有位胃癌患者愿意为我捐献眼角膜的时候，我并没有感到意外，我只是在想，即使好了，也再也见不到妈妈了吧。<br>

&nbsp;&nbsp;&nbsp;&nbsp;手术做得很成功，我以为一切都已经步入了正轨，却不曾想到当黑暗弥漫而来时，再璀璨的阳光也无济于事。<br>

&nbsp;&nbsp;&nbsp;&nbsp;谣言四起，有人说，父亲执刀的那位胃癌患者，如果不是因为父亲的失误，说不定还可以在这个世界上多活几年。<br>

&nbsp;&nbsp;&nbsp;&nbsp;又有人说，父亲是为了给我做眼角膜移植手术，故意让那场手术失败的。<br>

&nbsp;&nbsp;&nbsp;&nbsp;媒体和周遭的舆论让父亲不得不选择离开医院，一周后，父亲因酒后驾驶也随着母亲离开了我。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我知道那并不是一场意外，父亲早已签好的人体器官捐献协议，并写好了遗书。<br>

&nbsp;&nbsp;&nbsp;&nbsp;他说，周晓，不要怨怼你所面对的一切。<br>

&nbsp;&nbsp;&nbsp;&nbsp;父亲不会懦弱到被舆论击垮，我只好相信，父亲的确是为了我做错了事。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我搬了家，学会了抽烟喝酒，迷上了去各个论坛编写各种各样的故事，因为我知道这是唯一可以与黑夜对峙并养活自己的方式。<br>

&nbsp;&nbsp;&nbsp;&nbsp;直到我开始给艾希做枪手，才开始有了正常的作息。陆向北是在他管理的一个论坛里遇到艾希的，也可以说，是艾希找上了陆向北。<br>

&nbsp;&nbsp;&nbsp;&nbsp;那时候陆向北喜欢将我写的故事贴到自己的版块上，然后有一天，艾希给他发了一张小纸条说，嘿，给我做枪手吧。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我按照陆向北的指示开始过上了人类的正常生活，早睡早起，但烟酒却怎样也戒不掉，就算真的戒掉了，周晓也早已经不是当年那个周晓了。<br>

&nbsp;&nbsp;&nbsp;&nbsp;陆向北在我的屋子里转了一圈，将才刚冰好的啤酒白酒葡萄酒全部装进了垃圾袋，想了想，挺不情愿地放了葡萄酒一马。<br>

&nbsp;&nbsp;&nbsp;&nbsp;他说：“周晓，你看看你现在是个什么样子，你的眼袋比你的胸还要下垂啊!”<br>

&nbsp;&nbsp;&nbsp;&nbsp;他又说：“你怎么能这样对自己!”<br>

&nbsp;&nbsp;&nbsp;&nbsp;他还想说些什么，却被我打断，我说：“陆向北你以为你被我爸妈灵魂附体了啊你，你凭什么管我这个管我那个啊你，你是不是喜欢我啊你!”<br>

&nbsp;&nbsp;&nbsp;&nbsp;陆向北一把把我从椅子上揪起来，声音比我还高了八度：“我喜欢你怎么的，我就是喜欢你了怎么着吧!”<br>

&nbsp;&nbsp;&nbsp;&nbsp;喊完，世界和平了，屋子里静得吓人。<br>

&nbsp;&nbsp;&nbsp;&nbsp;唉，陆向北真是长大了，以前的陆向北多可爱，肥肥的，憨憨的，只会对我好，从不会对我大声说话。我默默地感慨着，斜睨他微微泛红的脸。<br>

&nbsp;&nbsp;&nbsp;&nbsp;陆向北低头咳嗽了两声，从口袋里掏出一块橡皮给我看，大耳朵的熊猫橡皮。陆向北说：“这是你七岁那年送给我的橡皮，我一直没舍得用，我想等将来再遇见你的时候再拿来用，可是我到现在还是舍不得用。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;我看着那块熊猫橡皮，看着他掌心里的芬芳城池，心里忽然间变得很暖，很平静。是再多的香烟和酒精都没法给予的那种平静。<br>

&nbsp;&nbsp;&nbsp;&nbsp;毕竟，不是每个女孩儿都可以跟自己分开十多年的橡皮再相遇的。<br>

                <h3>004 我看见他眼中有不忍一闪而过，那是包治百病起死回生的良药</h3>

&nbsp;&nbsp;&nbsp;&nbsp;再去找顾晨曦的时候我买了很多香蕉，听说这是容易让人快乐的食物。我还为自己买了一颗巨大的石榴，顾晨曦给我摆臭脸的时候，我就坐在注射台上一边摇晃着腿一边吐石榴籽。<br>

&nbsp;&nbsp;&nbsp;&nbsp;后来索性网购了一套护士服，白天到他的店里当助手，晚上回到家继续做枪手。<br>

&nbsp;&nbsp;&nbsp;&nbsp;怎奈白昼太过短暂，只够顾晨曦朝我翻几个白眼。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我说：“顾晨曦，你跟我说说话吧，我总不能晚上对着电脑聊天不是?人类是需要沟通的。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;我说：“啊?你不喝牛奶啊，你不喝你就跟我说啊，倒掉了多浪费。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;我说：“你平日里都不刮胡子，是不是想程子回来说，喂，整理下你的胡子啊浑蛋。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;顾晨曦终于有了反应，他不再跟那些猫猫狗狗深情对视了，他看了我一眼，眼神冷得吓人。说实话，我有些后悔了，我后悔当着他的面提起程子，明知道这是他心底最新鲜也永远新鲜的伤疤，揭不得，可我偏偏要这样说，真是讨人嫌。<br>

&nbsp;&nbsp;&nbsp;&nbsp;可是顾晨曦，你又怎么会知道，此时此刻的我，是怎样地妒着那个素未谋面的女孩儿，那个死死地霸占着你整颗心的姑娘，我忌妒得就要发疯了啊。<br>

&nbsp;&nbsp;&nbsp;&nbsp;窗外有灰色的飞鸟成群地飞过，晚风的味道里夹着湿漉漉的松木香气。<br>

&nbsp;&nbsp;&nbsp;&nbsp;顾晨曦说：“给我gun。<br>

&nbsp;&nbsp;&nbsp;&nbsp;与此同时，我上前一步，揪住顾晨曦雪白的衣领，踮起脚尖，特别臭流氓地吧唧了一下他的唇角。<br>

&nbsp;&nbsp;&nbsp;&nbsp;顾晨曦愣了一下，用那双平日里特别温柔地抚摸小猫小狗的手，将我推开。<br>

&nbsp;&nbsp;&nbsp;&nbsp;唉，真是造孽的情景，我想，以后如果再写故事，一定要给故事里的痴男怨女一个好的结局，原来我笔下那些爱而不得的姑娘们，是这样的心疼，闷重，且窒息。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我咬咬牙，拼死忍住了眼眶里晃来晃去的眼泪。我说：“顾晨曦，你可以不停地更换女朋友，鬈发大嘴巴眯眯眼罗圈腿，这些你都不挑，为什么我就不可以?!”<br>

&nbsp;&nbsp;&nbsp;&nbsp;我想我真的是疯了，那时的年少轻狂不管不顾，如今想来，究竟是难过的成分多一些，还是庆幸的成分多一些，我已经分辨不清了。<br>

&nbsp;&nbsp;&nbsp;&nbsp;但我知道，无论同样的场景重复多少次，我还是会像那一天一样，做出一样大胆的动作，说出一样冒失但却字字都比珍珠还要真的话。<br>

&nbsp;&nbsp;&nbsp;&nbsp;顾晨曦的眸色暗了下去，像是在极力隐忍。我却继续咄咄逼人地喊：“你和她们在一起，为的是忘了程子离开的疼，那你和我在一起，我一样可以让你忘了程子离开的疼!”<br>

&nbsp;&nbsp;&nbsp;&nbsp;说到这里，我心里颤的厉害。<br>

&nbsp;&nbsp;&nbsp;&nbsp;顾晨曦淡淡的问我：“你以为你能和他们比 ？”<br>
                
&nbsp;&nbsp;&nbsp;&nbsp;我脑子里嗡嗡作响，还未还得及说些什么，牵着儿子走进来的陆向北喊了一句“kao，你TM敢骂她”，便朝着顾晨曦一拳挥了过去。<br>

&nbsp;&nbsp;&nbsp;&nbsp;那是斯斯文文的陆向北第一次骂脏话，也是憨厚老实的陆向北第一次动手打架。<br>

&nbsp;&nbsp;&nbsp;&nbsp;结局显而易见，我左手牵着儿子，右手扶着差点儿被打成猪头的陆向北，一步一步走出了宠物之家。<br>

&nbsp;&nbsp;&nbsp;&nbsp;ye、se就那么厚重地压了下来。<br>
                
&nbsp;&nbsp;&nbsp;&nbsp;我停下来，脱下护士服，转身走进店里，将衣服放在桌子上，再转身走出来。有那么一瞬间，我看见顾晨曦的眼中有不忍一闪而过，那是包治百病起死回生的良药，带着一点点的心疼，一点点的愧疚，一点点的冷漠，兴许，还有一点点的……留恋。<br>

&nbsp;&nbsp;&nbsp;&nbsp;街道很长，我们走了很久，我想问问儿子，顾晨曦，那个我深深迷恋的小青年，他是不是在我们的身后，一直看着我的背影，不肯离去。<br>

&nbsp;&nbsp;&nbsp;&nbsp;实际上，我多想亲自回过头去确认一下。只是，满脸泪痕和鼻涕的我，一定是丑毙了。<br>

&nbsp;&nbsp;&nbsp;&nbsp;那天晚上，我带着陆向北去街尾的一家小诊所包扎伤口。他被打得不轻，眼眶青紫，嘴角也破了，憨厚的手指竟然也骨头错位。他躺在那里任由医生对他上下其手，悲惨的叫声让儿子十分不屑地摇着尾巴走了出去。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我也走了出去，抱着儿子暖呼呼的脖子哭得直哆嗦。我想陆向北可真是倒霉啊，七岁那年，他胖得没有天理，深受小朋友们的排挤，只有我愿意带着他玩儿。<br>

&nbsp;&nbsp;&nbsp;&nbsp;他便以为我是全天下最好的女孩儿，实际上，我只是因为跟着陆向北有肉吃，实际上，我也曾经嫌弃过这个小胖子。<br>

&nbsp;&nbsp;&nbsp;&nbsp;可是陆向北不在意，他将自己全部的玩具和零食与我分享，可我只送过他一块小熊橡皮，还是因为那时候的我只喜欢小兔子，并不喜欢大耳朵熊猫。但陆向北却一直舍不得用，珍藏了十多年。<br>

&nbsp;&nbsp;&nbsp;&nbsp;出国前，他哭得脸都青了，他说“周晓怎么办呀，没有了我谁带你去吃酱猪脚呢”。<br>

&nbsp;&nbsp;&nbsp;&nbsp;出国后，我的每一次生日，都是陆向北第一个打来祝贺的电话，凌晨十二点，掐准了时间打来。我却从来也不接，我觉得睡觉要比接电话来得重要。<br>

&nbsp;&nbsp;&nbsp;&nbsp;再后来，陆向北辗转听说了我的遭遇，他二话不说办理了回国手续，因为他听说，我一个人很孤独，我想要养一只小狗，想要有个人跟我说说话。<br>

&nbsp;&nbsp;&nbsp;&nbsp;所以他带着儿子义无反顾地闯入了我的生活。<br>

&nbsp;&nbsp;&nbsp;&nbsp;你可相信，爱情最初的年龄只有七岁。<br>

                <h3>005 苔藓开花的时候，你会回来牵我的手</h3>

&nbsp;&nbsp;&nbsp;&nbsp;我辞去了继续为艾希做枪手的工作，也不再拎着香蕉去宠物之家吃石榴了。<br>

&nbsp;&nbsp;&nbsp;&nbsp;艾希将最后一笔稿酬汇给我，对我说“嘿，出来见一面吧”。<br>

&nbsp;&nbsp;&nbsp;&nbsp;所以我需要将自己好好地打扮一番，没办法，就像顾晨曦去海边思念程子时做的那样，我也必须刻意地让自己精神百倍起来。<br>

&nbsp;&nbsp;&nbsp;&nbsp;然后，在我们约定好的地点，我隔着巨大而透明的落地窗看见了顾晨曦，他穿白色的衬衣，眯着眼，低头喝一杯有着红色枸杞的茶。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我走过去，再自然不过地同他打招呼，并为自己点了杯柠檬汁。<br>

&nbsp;&nbsp;&nbsp;&nbsp;艾希，爱，曦。<br>

&nbsp;&nbsp;&nbsp;&nbsp;嗯，你猜得没有错，艾希就是程子的笔名，而我，就是顾晨曦制造出来的一个假象，一个程子并没有离开的假象。<br>

&nbsp;&nbsp;&nbsp;&nbsp;程子离开后，他想要找一个人来代替艾希，做她的影子，然后这个总喜欢以“嘿”来开头讲话的小青年，就可以如往常一样，在每个月底去同一家报刊亭购买印有“艾希”名字的杂志或书籍。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我最难过的便是如此，我对顾晨曦的爱，始终无法超越顾晨曦对程子的爱，这是一个事实，是一根毒针，刺进我的眉心夜夜撕扯着我的神经。<br>

&nbsp;&nbsp;&nbsp;&nbsp;顾晨曦坐在身后大片的光束里，肩膀仍是微微耸着，他说：“你带我去吃点东西吧，我很饿。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;于是我们来到人潮涌动的饮食街，点满满一桌子的菜，叫满满一箱子的酒。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我们是暴食症患者，患难与共，一起对抗腹中的饥饿。顾晨曦为我倒酒，麦黄色的酒精哗啦啦地翻腾着雪白的泡沫，他说：“我要走了，后天的机票。”<br>

&nbsp;&nbsp;&nbsp;&nbsp;我咕咚咕咚地给自己灌酒，梁朝伟说，你知道酒为什么好喝吗，因为它难喝。<br>

&nbsp;&nbsp;&nbsp;&nbsp;那一夜的酒格外好喝，我一边喝，一边说：“对不起啊，顾晨曦，对不起。”然后我哭得很委屈，真的，我长这么大都没有这样委屈过。<br>
                
&nbsp;&nbsp;&nbsp;&nbsp;如果我知道，我在这一生的轨迹里会遇见顾晨曦，那么我宁愿失明一辈子。<br>

&nbsp;&nbsp;&nbsp;&nbsp;宁愿失明一辈子，也不要程子捐献给我的眼角膜。<br>

&nbsp;&nbsp;&nbsp;&nbsp;对面的顾晨曦沉默不语，他的睫毛那样长，恍惚间像是挂着晶莹的露水。我哭着哭着就在想，我凭什么哭呢，凭什么用程子的眼睛哭给顾晨曦看呢。<br>

&nbsp;&nbsp;&nbsp;&nbsp;所以我举起酒杯，继续给自己灌酒，直到脑子里炸开了花，直到心被酒精完全淹没，我砰的一声一头栽在桌子上。<br>

&nbsp;&nbsp;&nbsp;&nbsp;朦胧间，有双微凉的手掌轻轻覆盖着我的眼睛，良久，是一句叹息的声音在耳边消散了尾音。<br>

&nbsp;&nbsp;&nbsp;&nbsp;那一晚，顾晨曦背着我走了长长的一条街，直到路灯亮了，城市暗了，他才将我背到住处。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我仿佛听见顾晨曦的心跳，就在咫尺，平稳悲伤的声音温柔地笼罩着我，我闻到木槿的香气。<br>

&nbsp;&nbsp;&nbsp;&nbsp;之后的我常常在想。<br>

&nbsp;&nbsp;&nbsp;&nbsp;如果程子没有得过胃癌。<br>

&nbsp;&nbsp;&nbsp;&nbsp;如果她没有捐献过她的眼角膜。<br>

&nbsp;&nbsp;&nbsp;&nbsp;如果我的父亲并没有出现过失误。<br>

&nbsp;&nbsp;&nbsp;&nbsp;如果那一天，我的电脑没有系统崩溃，如果我没有去修理我的电脑，如果顾晨曦没有打开我的文档，没有看到我与父亲站在一起的照片。<br>

&nbsp;&nbsp;&nbsp;&nbsp;如果真的有这些如果，我是不是可以允许自己再勇敢一些，再任性一些，再年少轻狂一些呢?<br>

&nbsp;&nbsp;&nbsp;&nbsp;我是不是可以不停地、不停地，在顾晨曦的耳边说着“我喜欢你”，直到他也发现其实我也还不错，其实我真的还不错呢?<br>

&nbsp;&nbsp;&nbsp;&nbsp;可是并没有这些如果，灰姑娘没有水晶鞋，大雄也没有多啦A梦，周晓也不会有如果。<br>

&nbsp;&nbsp;&nbsp;&nbsp;只是我确信，当天边泛起清冷白光的时候，那个落在我唇上的吻，凉的，带有眼泪味道的吻，绝对不会是我的杜撰。<br>

&nbsp;&nbsp;&nbsp;&nbsp;所以顾晨曦，我可不可以认为，其实你也是喜欢着我的，就如同我喜欢着你。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我是不是也可以相信，当苔藓开花的时候，你会回来牵我的手，跟我说，嘿，想死我了。<br>

                <h3>006 时光寂静，我们如此便是最好不过</h3>

&nbsp;&nbsp;&nbsp;&nbsp;很多年了，陆向北一直执著于带着我和儿子到处寻觅美食。<br>

&nbsp;&nbsp;&nbsp;&nbsp;日子过得寂静，我用艾希的笔名赚钱养活自己。我不再抽烟，也不再喝酒，我喜欢以一张干净淡定的脸庞出现在杂志的采访专栏里。<br>

&nbsp;&nbsp;&nbsp;&nbsp;我知道在这个世界的某一个角落，一定会有个喜欢以“嘿”字开头讲话的小青年，他留着并不惹人嫌的胡楂，立在某个报亭低头翻看印有“艾希”两个字的全部杂志。<br>

&nbsp;&nbsp;&nbsp;&nbsp;也许他会翻到一个微微有些发胖，低眉顺眼地浅笑着的姑娘。<br>

&nbsp;&nbsp;&nbsp;&nbsp;也许他的手指会像抚摸小猫小狗那样充满温度地轻轻拂过她的面容。<br>

&nbsp;&nbsp;&nbsp;&nbsp;只是，他落满阳光的胡楂，我却再也没有机会伸手碰一碰了。<br>
                <br><br><br>
 <p>
    <span style="white-space:nowrap;">  
文章来源于互联网，刘坤整理提供。
    </span>    
</p>               
 
<p>
    <span style="white-space:nowrap;">  
        <font face=Times New Roman> <a href="http://www.sishen.ga" target="_blank"><u>http://www.sishen.ga/</u></a>  </font>     
    </span>    
</p> 

                <div><br /></div>
            </ul>
            <div class="keybq">
                <p><span>我是刘坤，我为自己代言！</span></p>

            </div>
            <div class="ad"></div>
            <div class="nextinfo">
                <p>上一篇：<a href='jilu-02.php'>【死神】你无法体会我的孤独</a></p>
                <p>下一篇：<a href='jilu-04.php'>这是一种什么样的体验</a></p><br>
            </div>

          <TABLE borderColor=green  height=0 width=1028 cellPadding=0 width=100 align=center border=1>
<TBODY>
<TR>
<TD>
    
</TD></TR></TBODY></TABLE><br>
            

<!-- 评论代码 -->
            
        </div>
        
        
        
                <aside class="right">

            <div class="blank"></div>


        </aside>
    </article>

        </div>
        <div id="r_box">
            <aside class="right">
                <div class="rnav">
                    <ul>
                        <li class="rnav1"><a href="http://vip.xcsee.cn" target="_blank">死神影视</a></li>
                        <li class="rnav2"><a href="http://www.weiqing.cf/weiqing.html" target="_blank">魏晴专属</a></li>
                        <li class="rnav3"><a href="jilu.php" target="_blank">生活记录</a></li>
                        <li class="rnav4"><a href="yinyue.php" target="_blank">音乐欣赏</a></li>
                    </ul>
                </div>
                    </article>
<footer>
  <p>Design by 刘坤</p>
</footer>
</body>
</html>